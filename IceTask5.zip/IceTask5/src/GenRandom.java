
import java.util.Random;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ST10150220
 */
public class GenRandom {
    public static void main (String args []){
        int [] nums = new int [20];
        Random rand = new Random();
        for(int i = 0; i < nums.length; i++){
            nums[i] = rand.nextInt(50) + 1;
        }
        
    Scanner sc = new Scanner (System.in);
    System.out.print("Enter a number to search for in the array: ");
    int userNum = sc.nextInt();
    int index = -1;
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] == userNum) {
                index = i;
                break;
            }
        }
        
     if (index != -1) {
            System.out.println("Searched for: " + userNum + " Number found at: " + index);
        } else {
            System.out.println("Searched for: " + userNum + " Number was not found");
        }
     
     sc.close();
    }
}
